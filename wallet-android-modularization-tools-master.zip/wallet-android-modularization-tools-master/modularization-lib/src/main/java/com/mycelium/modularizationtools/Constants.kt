package com.mycelium.modularizationtools

abstract class Constants {
    companion object {
        val TAG = "c.m.mt"
        @JvmStatic
        val SETTINGS = "com.mycelium.action.SETTINGS"
    }
}
