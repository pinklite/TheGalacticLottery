package com.samourai.wallet;

public interface OpCallback {
	public void onSuccess();

	public void onFail();
}