# Donations

If these guides have helped you consider making a donation

_This is an incomplete list, many more have contributed their time and effort to further the documention & ecosystem surrounding Samourai Wallet_

If your a contributor and aren't on the list, but would like to be added, DM @crazyk031 on Twitter or Telegram. 


### Dev Team

Most of the information in these guides was created by the Dev Team, you can show your support by donating to their PayNym! 

<img src="https://paynym.is/PM8TJVzLGqWR3dtxZYaTWn3xJUop3QP3itR4eYzX7XvV5uAfctEEuHhKNo3zCcqfAbneMhyfKkCthGv5werVbwLruhZyYNTxqbCrZkNNd2pPJA2e2iAh/avatar" width="300" height="300" /> 


[+samouraiwallet](https://paynym.is/+samouraiwallet) 
PM8TJVzLGqWR3dtxZYaTWn3xJUop3QP3itR4eYzX7XvV5uAfctEEuHhKNo3zCcqfAbneMhyfKkCthGv5werVbwLruhZyYNTxqbCrZkNNd2pPJA2e2iAh

[![BIP47 payment code](http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=PM8TJVzLGqWR3dtxZYaTWn3xJUop3QP3itR4eYzX7XvV5uAfctEEuHhKNo3zCcqfAbneMhyfKkCthGv5werVbwLruhZyYNTxqbCrZkNNd2pPJA2e2iAh&qzone=1&margin=0&size=200x200&ecc=L)](https://paynym.is/+samouraiwallet)

### Crazyk031

I have worked to convert this information into markdown to be hosted on the github, as well as provide links so the github is a jumping off point of all the information/links of the Samourai ecosystem information curated in one place. It is my continued goal to further the spread of info about Samourai Wallet! 


<img src="https://paynym.is/PM8TJQQcNHFNZhPfU91bBu8mU8vezK8Bh5ybTMY9VD1pTHZN6jijk8SDRMzQ5WfE3j5T7whSzShtK74HsY6qtC3UFjBQRyN7BQn7RD27zhA2hTQARK4V/avatar" width="300" height="300" /> 

[+fancysurf42F](https://paynym.is/+fancysurf42F) 
PM8TJQQcNHFNZhPfU91bBu8mU8vezK8Bh5ybTMY9VD1pTHZN6jijk8SDRMzQ5WfE3j5T7whSzShtK74HsY6qtC3UFjBQRyN7BQn7RD27zhA2hTQARK4V

[![BIP47 payment code](http://api.qrserver.com/v1/create-qr-code/?color=000000&bgcolor=FFFFFF&data=PM8TJQQcNHFNZhPfU91bBu8mU8vezK8Bh5ybTMY9VD1pTHZN6jijk8SDRMzQ5WfE3j5T7whSzShtK74HsY6qtC3UFjBQRyN7BQn7RD27zhA2hTQARK4V&qzone=1&margin=0&size=200x200&ecc=L)](https://paynym.is/+fancysurf42F)
