package com.coinomi.core.network;

/**
 * @author John L. Jegutanis
 */
public interface ConnectivityHelper {
    public boolean isConnected();
}
