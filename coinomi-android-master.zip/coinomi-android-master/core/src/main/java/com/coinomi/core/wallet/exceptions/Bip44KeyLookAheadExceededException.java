package com.coinomi.core.wallet.exceptions;

/**
 * @author John L. Jegutanis
 */
public class Bip44KeyLookAheadExceededException extends Throwable {
}
