package com.coinomi.core.wallet;

/**
 * @author John L. Jegutanis
 */
public enum WalletPocketConnectivity {
    DISCONNECTED,
    CONNECTED,
    WORKING;
}
